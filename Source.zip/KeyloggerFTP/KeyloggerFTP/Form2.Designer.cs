﻿namespace KeyloggerFTP
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.segundos = new System.Windows.Forms.RadioButton();
            this.minutos = new System.Windows.Forms.RadioButton();
            this.horas = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // segundos
            // 
            this.segundos.AutoSize = true;
            this.segundos.Location = new System.Drawing.Point(12, 66);
            this.segundos.Name = "segundos";
            this.segundos.Size = new System.Drawing.Size(73, 17);
            this.segundos.TabIndex = 0;
            this.segundos.TabStop = true;
            this.segundos.Text = "Segundos";
            this.segundos.UseVisualStyleBackColor = true;
            this.segundos.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // minutos
            // 
            this.minutos.AutoSize = true;
            this.minutos.Location = new System.Drawing.Point(91, 66);
            this.minutos.Name = "minutos";
            this.minutos.Size = new System.Drawing.Size(62, 17);
            this.minutos.TabIndex = 1;
            this.minutos.TabStop = true;
            this.minutos.Text = "Minutos";
            this.minutos.UseVisualStyleBackColor = true;
            this.minutos.CheckedChanged += new System.EventHandler(this.minutos_CheckedChanged);
            // 
            // horas
            // 
            this.horas.AutoSize = true;
            this.horas.Location = new System.Drawing.Point(159, 66);
            this.horas.Name = "horas";
            this.horas.Size = new System.Drawing.Size(53, 17);
            this.horas.TabIndex = 2;
            this.horas.TabStop = true;
            this.horas.Text = "Horas";
            this.horas.UseVisualStyleBackColor = true;
            this.horas.CheckedChanged += new System.EventHandler(this.horas_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 22);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(182, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Ingrese tipo de tiempo entre capturas";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(30, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Ingrese tiempo";
            // 
            // textBox
            // 
            this.textBox.Location = new System.Drawing.Point(112, 114);
            this.textBox.Name = "textBox";
            this.textBox.Size = new System.Drawing.Size(100, 20);
            this.textBox.TabIndex = 5;
            this.textBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(78, 168);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 6;
            this.button1.Text = "listo";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(245, 203);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.textBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.horas);
            this.Controls.Add(this.minutos);
            this.Controls.Add(this.segundos);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton segundos;
        private System.Windows.Forms.RadioButton minutos;
        private System.Windows.Forms.RadioButton horas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox;
        private System.Windows.Forms.Button button1;
    }
}