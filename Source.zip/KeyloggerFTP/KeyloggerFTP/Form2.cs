﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KeyloggerFTP
{
    public partial class Form2 : Form
    {
        int tiempo;

        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            if (segundos.Checked)
            { 
                string tiempoS;
                tiempoS = textBox.Text;
                tiempo = Int32.Parse(tiempoS)*1000;
        
            }
            else if (minutos.Checked)
            {
                string tiempoS;
                tiempoS = textBox.Text;
                tiempo = Int32.Parse(tiempoS)*60*1000;
             
            }
            else if (horas.Checked)
            {
                string tiempoS;
                tiempoS = textBox.Text;
                tiempo = Int32.Parse(tiempoS)*3600*1000;
                
            }
            else
            {
                MessageBox.Show("Error, por favor seleciona el tipo de dato");
            }

            this.Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
          
        }

        private void minutos_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void horas_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
